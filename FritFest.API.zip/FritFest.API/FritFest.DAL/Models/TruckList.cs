﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FritFest.DAL.Models
{
    public class TruckList
    {
        public Guid FoodTruckId { get; set; }
        public Guid EditieId { get; set; }
    }
}
