﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FritFest.DAL.Models
{
    public class Dag
    {
        public Guid DagId { get; set; }
        public DateTime Date { get; set; }
    }
}
