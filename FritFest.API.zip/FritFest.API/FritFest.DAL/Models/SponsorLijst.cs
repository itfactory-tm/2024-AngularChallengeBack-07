﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FritFest.DAL.Models
{
    public class SponsorLijst
    {
        public Guid SponsorId { get; set; }
        public Guid EditieId { get; set; }
    }
}
